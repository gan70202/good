<?php

class UnconfirmedAmountResponse
{
    /** @var string */
    public $amount;
    /** @var bool */
    public $is_enough;
}
