<?php

class CoinpayApiRequest
{
    public function __construct()
    {

    }
}
