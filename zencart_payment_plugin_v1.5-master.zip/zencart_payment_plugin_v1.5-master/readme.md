# BX CoinPay plug-in for Zen Cart
---

Project: Coinpay.in.th Merchant Account
Module: Zencart Module Payment
Author: info@coinpay.in.th

## Installation:
* Create a merchant account at https://bx.in.th/
* Copy all contents of the `/zencart_payment_plugin_v1.5/` folder to your root Zencart directory
* Go to Zencart `Admin -> Modules -> Payment -> Click on "BX CoinPay"` module and `"Install"`
* "Edit" the BX CoinPay module and enter your API ID Key https://bx.in.th
